#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "funcion.h"

void CasoMedio(int*, int);
void CasoMedio(int *A, int size) {
  int i;
  for (i = 0; i < size; i++)
        A[i] = rand();
}

int main(int argc, char* argv[])
{
    srand(time(NULL));
    int size = atoi(argv[1]);
    int iterations = 10000, i;
    long sum = 0;
    int* array = malloc(size * sizeof(int));
    
    for (i = 0; i < iterations; i++) {
	CasoMedio(array, size);
	sum += Producto2Mayores(array, size);
    }
    long average = sum/iterations;
    float fx = (8 * size - 7) / 3;
    printf("Size: %d\nTeorico: %.0f\nPractico: %ld\n", size, fx, average);
    free(array);
    return 0;
}
