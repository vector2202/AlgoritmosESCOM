#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "funcion.h"

void PeorCaso(int*, int);
void PeorCaso(int* A, int size)
{
    int i;
    for(i = 0; i < size; i++)
	A[i] = i;
}
    
int main(int argc, char* argv[])
{
    int size = atoi(argv[1]);
    int i, sum = 0;
    int* array = malloc(size * sizeof(int));
    PeorCaso(array, size);
    int fx = (3 * size - 3);
    printf("Size: %d\nTeorico: %d\nPractico: %d\n", size, fx, Producto2Mayores(array, size));
    free(array);
    return 0;
}
