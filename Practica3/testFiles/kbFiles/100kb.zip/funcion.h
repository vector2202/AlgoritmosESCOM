//funciones para contar operaciones
int mayorque(int a, int b, int* operations){(*operations)++; return (a > b) ? 1 : 0;}
int asignacion(int n, int* operations){(*operations)++; return n;}

int Producto2Mayores(int A[], int n)
{
    int operations = 0;
    int mayor1, mayor2;
    if(mayorque(A[0], A[1], &operations)){
	mayor1 = asignacion(A[0], &operations);
	mayor2 = asignacion(A[1], &operations);
    }
    else{
	mayor1 = asignacion(A[1], &operations);
	mayor2 = asignacion(A[0], &operations);
    }
    int i = 2;
    while(i < n){
	if(mayorque(A[i], mayor1, &operations)){
	    mayor2 = asignacion(mayor1, &operations);
	    mayor1 = asignacion(A[i], &operations);
        } else if (mayorque(A[i], mayor2, &operations)) {
	    mayor2 = asignacion(A[i], &operations);
        }
        i++;
    }
    return operations;
}
