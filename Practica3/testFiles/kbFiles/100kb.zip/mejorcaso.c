#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "funcion.h"

void MejorCaso(int*, int);
void MejorCaso(int* A, int size)
{
    int i;
    for(i = 0; i < size; i++)
	A[i] = size - i;
}

    
int main(int argc, char* argv[])
{
    int size = atoi(argv[1]);
    int i, sum = 0;
    int* array = malloc(size * sizeof(int));
    MejorCaso(array, size);
    int fx = (2 * size - 1);
    printf("Size: %d\nTeorico: %d\nPractico: %d\n", size, fx, Producto2Mayores(array, size));
    free(array);
    return 0;
}
